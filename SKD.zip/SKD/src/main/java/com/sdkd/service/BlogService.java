package com.sdkd.service;

import com.sdkd.dto.BlogDTO;
import com.sdkd.model.Blog;

import java.util.List;

/**
 * @author Young
 * @date 2020/4/11 13:54
 * @see com.sdkd.service
 */
public interface BlogService {
    List<BlogDTO> findAll();
    Blog findById(Integer blog_id);
    void saveBlog(BlogDTO blogDTO);
}
