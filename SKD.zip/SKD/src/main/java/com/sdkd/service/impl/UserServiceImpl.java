package com.sdkd.service.impl;

import com.sdkd.dao.UserDao;
import com.sdkd.dto.UserDTO;
import com.sdkd.model.User;
import com.sdkd.model.c_User;
import com.sdkd.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author Young
 * @date 2020/4/11 13:56
 * @see com.sdkd.service.impl
 */
@Service
public class UserServiceImpl implements UserService {
    @Resource
    private UserDao userDao;

    @Override
    public User checkLogin(Integer userName, String password) {
        User user = userDao.checkUser(userName,password);
        return user;
    }

    @Override
    public List<c_User> findAll() {
        return null;
    }

    @Override
    public int countByName(String name) {
        return 0;
    }
}
