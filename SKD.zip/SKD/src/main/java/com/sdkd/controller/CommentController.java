package com.sdkd.controller;

import com.alibaba.fastjson.JSON;
import com.sdkd.model.Comment;
import com.sdkd.model.User;
import com.sdkd.service.CommentService;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author Young
 * @date 2020/5/2 0:34
 * @see com.sdkd.controller
 */

@Controller
@RequestMapping("/user/comment")
public class CommentController {
    @Resource
    private CommentService commentService;

    @RequestMapping("/answer")
    public String answer(){
        return "answer";
    }

    @RequestMapping(value = "/replyComment")
    public @ResponseBody ModelMap replyComment(HttpServletRequest request,  @RequestParam(value = "fatherId", required = false) String fatherId, @RequestParam(value = "content", required = false) String content){
        ModelMap mm = new ModelMap();
        Comment comment = commentService.findComment(Integer.parseInt(fatherId));
        HttpSession session = request.getSession();
        User user = (User)session.getAttribute("USER");
        //回复的comment
        Comment reply = new Comment();
        reply.setBlog_id(comment.getBlog_id());
        reply.setUser_id(user.getId());
        reply.setComment_text(content);
        reply.setComment_date(new Date());
        reply.setParent_id(Integer.parseInt(fatherId));
        reply.setPraise_count(0);
        commentService.replyComment(reply);
        mm.addAttribute("str", JSON.toJSONString(reply));
        return mm;
    }

    @RequestMapping(value = "/replyBlog")
    public @ResponseBody ModelMap replyBlog(HttpServletRequest request,  @RequestParam(value = "blogId", required = false) String blogId, @RequestParam(value = "content", required = false) String content){
        ModelMap mm = new ModelMap();
        HttpSession session = request.getSession();
        User user = (User)session.getAttribute("USER");
        //回复的comment
        Comment reply = new Comment();
        reply.setBlog_id(Integer.parseInt(blogId));
        reply.setUser_id(user.getId());
        reply.setComment_text(content);
        reply.setComment_date(new Date());
        reply.setParent_id(null);
        reply.setPraise_count(0);
        commentService.replyComment(reply);
        mm.addAttribute("str",JSON.toJSONString(reply));
        return mm;
    }
}
