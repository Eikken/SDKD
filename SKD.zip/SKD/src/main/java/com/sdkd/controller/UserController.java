package com.sdkd.controller;

import com.sdkd.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;

/**
 * @author Young
 * @date 2020/4/12 0:17
 * @see com.sdkd.controller
 */
@Controller
@RequestMapping("/user")
public class UserController {
    //bean name
    @Resource
    private UserService userService;

    @RequestMapping("/userManagement")
    public String userManagement(){
        System.err.println("login userManagement------->");
        return "userManagement";
    }

}

