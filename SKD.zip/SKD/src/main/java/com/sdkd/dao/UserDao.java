package com.sdkd.dao;

import com.sdkd.model.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Young
 * @date 2020/3/25 21:00
 * @see com.sdkd.dao
 * 这里是要实现的接口
 */
@Repository
public interface UserDao {

    //按id查找user
    User findById(Integer id);
    User checkUser(@Param("id") Integer id, @Param("password") String password);

    void insertUser();
    void deleteUser();
    void updateUser();

//    c_User findById(String id);
//    List<c_User> findAll();
//    List<c_User> findByRoleId();
//    int countByName(String name);
//    int updateUser(c_User user);

}
