package com.sdkd.dao;

import com.sdkd.model.Blog;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * @author Young
 * @date 2020/4/11 12:51
 * @see com.sdkd.dao
 */
@Repository
public interface BlogDao {
    List<Blog> findAll();//获取所有帖子
    void saveBlog(@Param("user_id") Integer user_id,
                  @Param("blog_text") String blog_text,
                  @Param("blog_date") Date blog_date,
                  @Param("is_expert") Integer is_expert);
    //没有@Param 会报错：
    // org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.binding.BindingException:
    // Parameter 'id' not found. Available parameters are [arg2, arg1, arg0, param3, param1, param2]
    void deleteBlog(@Param("blog_id") Integer blog_id);
    void likeBlog(@Param("blog_id") Integer blog_id,@Param("praise_count") Integer praise_count);
    Blog findById(Integer blog_id);
}
