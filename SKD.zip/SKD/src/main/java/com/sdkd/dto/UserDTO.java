package com.sdkd.dto;

import com.sdkd.model.User;

/**
 * @author Young
 * @date 2020/4/11 13:50
 * @see com.sdkd.dto
 */
public class UserDTO extends User {
    private String isExpert;

    public String getIsExpert() {
        return isExpert;
    }

    public void setIsExpert(String isExpert) {
        this.isExpert = isExpert;
    }
}
